QUEST 3 STORAGE EXPLORER - AUTOMATIC LAUNCHER (WINDOWS)
======================================================

1. Extract the entire ZIP archive into a writable folder on your PC,
   for example D:\Quest3-Storage-Explorer\ .
2. Connect your Quest 3 over USB. In the headset, enable Developer Mode
   if needed and approve the USB debugging prompt.
3. Double-click Start-Quest3-Explorer.cmd .

On first run, the launcher:
- Checks for a working 64-bit Python 3.10+ and installs Python 3.13
  for your Windows user only if Python is missing.
- Downloads Google's official Android Platform-Tools into the local
  platform-tools\ folder if its adb.exe is not already working.
- Creates a local .venv Python environment, reusing installed packages
  when they are visible, and installs Androguard and dependencies if missing.
- Checks there is exactly one connected, authorised Quest.
- Starts quest3_app_explorer.py, which creates an offline interactive HTML
  report and a JSON data snapshot in this folder and opens the browser.

Later runs reuse working components and start the report directly.
Internet is required only for any components that need installing.

Optional: From cmd.exe or PowerShell, pass arguments via the .cmd launcher:
  .\Start-Quest3-Explorer.cmd --depth 5 --large-file-mb 64
  .\Start-Quest3-Explorer.cmd --all
  .\Start-Quest3-Explorer.cmd --no-large-files

Output:
  Quest3-App-Explorer.html   -- open in any web browser
  Quest3-App-Explorer.json   -- data snapshot for further analysis
  Quest3-App-Labels.json    -- cached human-readable game labels

IMPORTANT: The audit is read-only. It does not delete anything on your Quest.
The main disk audit may take longer on a device with many games and files.

Official downloads:
  Python: https://www.python.org/downloads/
  Google ADB: https://developer.android.com/tools/releases/platform-tools
  Androguard: https://pypi.org/project/androguard/

If a .venv becomes damaged, close the application, delete ONLY the .venv
folder, and double-click the launcher again to rebuild it. If ADB becomes
corrupt, delete ONLY the platform-tools folder and launch again.

The launcher does not make global PATH changes and does not require Administrator.
